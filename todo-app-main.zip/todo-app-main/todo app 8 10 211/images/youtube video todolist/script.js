function addItem(event){
    event.preventDefault();
    let text = document.getElementById("new-todo-input");
    console.log(text);
}